package lab2;

public final class Chances {

    public static boolean chance(double chance) {
        return Math.random() <= chance;
    }

}
